#!/bin/sh

exec 2>/dev/null
timeout 60 /home/fmtlab/fmtlab
